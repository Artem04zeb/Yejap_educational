<?php

// Данный файл осуществляет выход пользователя из сессии.

session_start();

// Перебирает все элементы сесси, чтобы их удалить, в итге $_SESSION будет пустой
foreach ($_SESSION as $key => $value) {
    unset($_SESSION[$key]);
}
// Переадресация на главную страницу

header('Location: ../../index.php');
