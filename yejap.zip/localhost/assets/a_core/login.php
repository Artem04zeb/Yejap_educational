<?php

// Данный файл осуществляет процесс авторизации, т.е. проверяет, есть ли пользователь в БД, верен ли пароль

session_start(); // Стартуем сессию, чтобы записывать в неё необхожимые данные

// Подключаемся к БД
require_once __DIR__ . '/connect.php';

// Сохраняем значения из $_POST, чтобы данные легче было записать в SQL
$email = $_POST['email'];
$password = $_POST['password'];

$check = mysqli_query($connect, "SELECT * FROM `students`WHERE email='$email'");
$ar = mysqli_fetch_all($check, 1);

if(mysqli_num_rows($check) > 0){
    if(password_verify($password, $ar[0]['password'])){
        $_SESSION['full_name'] = $ar[0]['lname'] . ' ' . $ar[0]['fname'];
        $_SESSION['id'] = $ar[0]['id'];
        $_SESSION['email'] = $ar[0]['email'];
        $_SESSION['courses'] = explode(' ', $ar[0]['courses']);
    }
    else{
        $_SESSION['message'] = 'Неверный логин или пароль';
    }
}
// Переадресация в личный кабинет
header('Location: ../../pages/personal_page.php');
