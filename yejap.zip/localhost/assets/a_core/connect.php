<?php

// Данный файл осуществляет подключение к Базе Данных(БД)

// Переменные ниже могут меняется в зависимости от того, проект на сервере или на локальном хосте
$hostname = 'localhost';
$username ='root';
$password = '';
$database = 'students';

$connect = mysqli_connect($hostname, $username, $password, $database);

// Если не удалось подключиться - вывод сообщения
// Если удалось - устанавливаем кодировку
if (!$connect){
    die('<br>ERROR DUE CONNECT');
}
else{
    mysqli_set_charset($connect, 'utf8');
}
