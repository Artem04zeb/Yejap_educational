<?php

// Данный файл осущствляет процесс регистрации. Если соблюдены все условия, то данные пользователя будут записаны в БЖ

session_start();

require_once __DIR__ . '/connect.php';

// Если длинна пароля < 7, тогда выдать соответственное сообщение
if (strlen($_POST['password1']) < 7  or strlen($_POST['password2']) < 7){
    $_SESSION['message'] = 'Слишком короткий пароль';
}// Если пароли не совпадают, тогда выдать соответственное сообщение
elseif($_POST['password1'] != $_POST['password2']){
    $_SESSION['message'] = 'Пароли не сопадают';
} // Если все условия выполнены:
else{
    // Сохраняем значения из $_POST в переменные, чтобы было легче грузить их в SQL запрос
    $email = $_POST['email'];
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];

    // Пароль шифруется, чтобы в случае перехвата, его нельзя было украсть
    $password = password_hash($_POST['password1'], PASSWORD_DEFAULT);

    // Если не удалось загрузить данные на сервер, тогд выдать соотвественное сообщение
    if (!mysqli_query($connect, "INSERT INTO `students` (`id`, `email`, `fname`, `lname`, `courses`, `password`) 
    VALUES (NULL, '$email', '$fname', '$lname', NULL, '$password')")){
        $_SESSION['message'] = 'Ошибка при загрузке данных';
    }
    else{
        $_SESSION['message'] = 'Регистрация пройдена успешно!';
    }
}
// Переадресация на главную страницу
header('Location: ../../index.php');