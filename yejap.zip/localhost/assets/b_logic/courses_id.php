<?php

require_once __DIR__ . '/../blocks_html/blocks.php ';

// Данный массив служит для отображения превью курса. Каждому курсу соответсвует ID
$courses_dict = [
    0 => $mechanika,
    3 => $mechanika,
    2 => $mechanika,
    1 => $mechanika
];
