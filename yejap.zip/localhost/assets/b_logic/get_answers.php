<?php

// Данный файл берёт строку из БД с правильными ответами для данного курса.

session_start();
require_once __DIR__ . '/../a_core/connect.php';

// Сохраняем в переменную, чтобы легче грузить в SQL
$id_course = $_SESSION['course_id'];
// Берём из БД строку с ответами
$answers = mysqli_fetch_all(mysqli_query($connect, "SELECT * FROM `courses`WHERE id_course = '$id_course' "), 1);
$answers = $answers[0]['answers'];

// Сохраняем готовые ответы в массив
$answers_exploded = explode(';', $answers);

