<?php

// Данный файл осуществляет процесс добавления курса в БД для пользователя

session_start();
require_once __DIR__ . '/../a_core/connect.php';

# Сохраняем в переменную, чтобы легче было в SQL вставить
$id = $_SESSION['id'];

# Берём из базы пользователя с нужным id
$requests = mysqli_query($connect, "SELECT * FROM `students` WHERE id = '$id' ");
$requests = mysqli_fetch_all($requests, 1);

# Если данный курс имеется в базе данных, значит он находится в массиве
# Если курс уже добавлен, тогда выдать соответствующее сообщение
if (in_array($_POST['course'], explode(' ', $requests[0]['courses']))){
    $_SESSION['message'] = 'Данный курс уже добавлен в избранное';
}
else{# Если курс не добавлен, тогда сохранить id курса в БД
    $course = $requests[0]['courses'] . ' ' .$_POST['course'];
    mysqli_query($connect, "UPDATE students SET courses = '$course' WHERE id = '$id' ");
}

# Переадресация на главную страницу
header('Location: ../../index.php');