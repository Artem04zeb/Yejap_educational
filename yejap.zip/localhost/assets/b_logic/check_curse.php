<?php

// Данный файл осуществляет проверку тестов.

session_start();
require_once __DIR__ . '/get_answers.php';
require_once __DIR__ . '/../a_core/connect.php';

// Сохраняем данные, чтобы легче вставить в SQL
$id_student = $_SESSION['id'];
$course_id = $_SESSION['course_id'];

// Если у пользователя ещё нет статистики и соответствующая
// ему ячейка с ответами пуста, тогда заполнить её шаблонной строкой с ответами
if(!(count(mysqli_fetch_all(mysqli_query($connect, "SELECT * FROM `statistics` WHERE `id_student` = '$id_student' AND `id_course` = '$course_id'"), 1)) > 0)) {
    $base = '0 0/0;1 0/0;2 0/0;3 0/0;4 0/0;5 0/0;6 0/0;7 0/0;8 0/0;9 0/0;';
    mysqli_query($connect, "INSERT INTO `statistics`(`id_student`, `id_course`, `points`) VALUES ('$id_student','$course_id','$base')");
    unset($base); // Убрать переменные, потому что мы их дальше не используем
}

// Подсчёт кол-ва правильных ответов
$points = 0; // Изначально, перед проверкой, кол-во правильных ответов равно нулю.
for($i = 0; $i < count($_POST)-1; $i++){
    if(explode(' ', $answers_exploded[$_POST['test_id']])[$i] == $_POST[$i]){
        $points++;
    }
}

// Берём из БД строку с ответами, чтобы их поменять.
$result = mysqli_fetch_all(mysqli_query($connect, "SELECT * FROM `statistics` WHERE `id_student` = '$id_student' AND `id_course` = '$course_id'"), 1)[0]['points'];
// Разделяем строку на массив
$result_exploded = explode(';', $result);
// В соответствующий тест записываем правильные ответы / среди всех
$result_exploded[$_POST['test_id']] = $points . '/' . ($_POST['quest_len']);
// Подготавливаем строку для SQL запроса
$sql_send = '';
// Собираем массив с отредактированными ответами снова в строку.
foreach ($result_exploded as $item) {
    $sql_send = $sql_send . $item . ';';
}
// Удаляем ненужные переменные
unset($result, $result_exploded);
// Удаляем из отредактированной строки последний символ: ";"
$sql_send = substr($sql_send, 0 , -1);
// Отправляем в БД строку с ответами
mysqli_query($connect, "UPDATE `statistics` SET `points`='$sql_send' WHERE `id_student` = '$id_student' AND `id_course` = '$course_id'");
// Переадресация обратно на страницу курса
header('Location: ../../course_page.php');
