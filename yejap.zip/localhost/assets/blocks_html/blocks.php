<?php

$header1 = '<div class="container">
        <header class="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom">
            <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-dark text-decoration-none">
                <svg class="bi me-2" width="40" height="32"><use xlink:href="#bootstrap"></use></svg>
                <span class="fs-4">Misos network</span>
            </a>

            <ul class="nav nav-pills">
                <li class="nav-item">
                <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#exampleModal1">
                    Зарегистрироваться
                </button>
                <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#exampleModal2">
                    Войти
                </button>
                <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#exampleModal3">
                    Выйти
                </button>
                </li>
                <!-- 
                <li class="nav-item"><a href="#" class="nav-link ">На всякий случай если нужна кнопка</a></li> 
                !-->    
            </ul>
        </header>
    </div>';


$footer1 = '<section class="p-4">

      <footer class="text-center text-lg-start bg-light text-muted">

        <div class="text-center p-4" style="background-color: rgba(0, 0, 0, 0.2);">
          
          <div class="container  p-4">
                <div class="col-lg-6 col-md-12 mb-4 mb-md-0 footer_about">
                    <h5>*********</h5>
                </div>
          </div>
            *******: 
                      <span class="text-reset link fw-bold" >*****</span>
                      <br>
          © 2022 Copyright:
            <a class="text-reset link fw-bold" href="https://www.misos.site/">*******</a>
        </div>

      </footer>

    </section>';

$mechanika = '<div class="course">
                    <img class="course_img" src="https://www.pinclipart.com/picdir/big/342-3427921_physics-atom-clipart.png" alt="">
                    <span class="course_name">Механика</span>
                    <a href="http://localhost/pages/course_page.php" class="btn course_btn">
                        Перейти к курсу
                    </a>
                </div>';
