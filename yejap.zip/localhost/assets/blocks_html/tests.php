<?php

$q0 = '<form action="check_curse.php" method="post" style="border: 2px solid black; padding: 20px">
                <span class="fs-4">Небольшой тест по кинематике</span>
                <input name="test_id" value="0" style="display: none;">
                <input name="quest_len" value="2" style="display: none;">
                <br><br>

                    <p>Сколько будет 2 + 2?</p>
                    <label><input name="0" type="radio" value="a">3</label>
                    <label><input name="0" type="radio" value="b">4</label>
                    <label><input name="0" type="radio" value="c">1</label>

                <br><br>

                    <p>Сколько будет 5 - 2?</p>
                    <label><input name="1" type="radio" value="a">3</label>
                    <label><input name="1" type="radio" value="b">2</label>
                    <label><input name="1" type="radio" value="c">1</label>

                    <br><br>
                    <button type="submit" value="but1">Проверить</button>

            </form>';

$q1 = '<form action="check_curse.php" method="post" style="border: 2px solid black; padding: 20px">
                        <span class="fs-4">Небольшой тест по положению тела</span>
                        <input name="test_id" value="1" style="display: none;">
                        <input name="quest_len" value="3" style="display: none;">

                        <br><br>

                        <p>Сколько будет 11 - 1?</p>
                        <label><input name="0" type="radio" value="a">10</label>
                        <label><input name="0" type="radio" value="b">4</label>
                        <label><input name="0" type="radio" value="c">1</label>

                        <br><br>
                        
                        <p>Сколько будет 12 * 0 ?</p>
                        <label><input name="1" type="radio" value="a">10</label>
                        <label><input name="1" type="radio" value="b">4</label>
                        <label><input name="1" type="radio" value="c">0</label>

                        <br><br>

                        <p>Сколько будет 4 - 2?</p>
                        <label><input name="2" type="radio" value="a">3</label>
                        <label><input name="2" type="radio" value="b">2</label>
                        <label><input name="2" type="radio" value="c">1</label>

                        <br><br>
                        <button type="submit" value="but1">Проверить</button>

                    </form>';


$q2 = '<form action="check_curse.php" method="post" style="border: 2px solid black; padding: 20px">
                        <span class="fs-4">Небольшой тест по скорости</span>
                        <input name="test_id" value="2" style="display: none;">
                        <input name="quest_len" value="2" style="display: none;">

                        <br><br>

                        <p>Сколько будет 3 * 1?</p>
                        <label><input name="0" type="radio" value="a">3</label>
                        <label><input name="0" type="radio" value="b">4</label>
                        <label><input name="0" type="radio" value="c">1</label>

                        <br><br>

                        <p>Сколько будет 4 * 2?</p>
                        <label><input name="1" type="radio" value="a">3</label>
                        <label><input name="1" type="radio" value="b">2</label>
                        <label><input name="1" type="radio" value="c">8</label>

                        <br><br>
                        <button type="submit" value="but1">Проверить</button>

                    </form>';

$q3 = '<form action="check_curse.php" method="post" style="border: 2px solid black; padding: 20px">
                        <span class="fs-4">Небольшой тест по ускорению</span>
                        <input name="test_id" value="3" style="display: none;">
                        <input name="quest_lenquest_len" value="2" style="display: none;">

                        <br><br>

                        <p>Сколько будет 11 - 1 * 2?</p>
                        <label><input name="0" type="radio" value="a">10</label>
                        <label><input name="0" type="radio" value="b">9</label>
                        <label><input name="0" type="radio" value="c">1</label>

                        <br><br>

                        <p>Сколько будет 4 - 0?</p>
                        <label><input name="1" type="radio" value="a">3</label>
                        <label><input name="1" type="radio" value="b">2</label>
                        <label><input name="1" type="radio" value="c">4</label>

                        <br><br>
                        <button type="submit" value="but1">Проверить</button>

                    </form>';

$q4 = '<form action="check_curse.php" method="post" style="border: 2px solid black; padding: 20px">
                        <span class="fs-4">Контрольный тест : Произвольное движение</span>
                        <input name="test_id" value="4" style="display: none;">
                        <input name="quest_len" value="2" style="display: none;">
                        <br><br>

                        <p>Сколько будет 11 - 1 * 2?</p>
                        <label><input name="0" type="radio" value="a">10</label>
                        <label><input name="0" type="radio" value="b">9</label>
                        <label><input name="0" type="radio" value="c">1</label>

                        <br><br>

                        <p>Сколько будет 4 - 0?</p>
                        <label><input name="1" type="radio" value="a">3</label>
                        <label><input name="1" type="radio" value="b">2</label>
                        <label><input name="1" type="radio" value="c">4</label>

                        <br><br>
                        <button type="submit" value="but1">Проверить</button>

                    </form>';

$q5 = '<form action="check_curse.php" method="post" style="border: 2px solid black; padding: 20px">
                        <span class="fs-4">Положение тела на окружности</span>
                        <input name="test_id" value="5" style="display: none;">
                        <input name="quest_len" value="2" style="display: none;">
                        
                        <br><br>

                        <p>Сколько будет 11 - 1 * 3?</p>
                        <label><input name="0" type="radio" value="a">10</label>
                        <label><input name="0" type="radio" value="b">9</label>
                        <label><input name="0" type="radio" value="c">8</label>

                        <br><br>

                        <p>Сколько будет 4 - 1?</p>
                        <label><input name="1" type="radio" value="a">3</label>
                        <label><input name="1" type="radio" value="b">2</label>
                        <label><input name="1" type="radio" value="c">4</label>

                        <br><br>
                        <button type="submit" value="but1">Проверить</button>

                    </form>';

$q6 = '<form action="check_curse.php" method="post" style="border: 2px solid black; padding: 20px">
                        <span class="fs-4">Угловая <скорость></скорость></span>
                        <input name="test_id" value="6" style="display: none;">
                        <input name="quest_len" value="2" style="display: none;">
                        <br><br>

                        <p>Сколько будет 1 - 1 ?</p>
                        <label><input name="0" type="radio" value="a">10</label>
                        <label><input name="0" type="radio" value="b">0</label>
                        <label><input name="0" type="radio" value="c">1</label>

                        <br><br>

                        <p>Сколько будет 4 - 1?</p>
                        <label><input name="1" type="radio" value="a">3</label>
                        <label><input name="1" type="radio" value="b">2</label>
                        <label><input name="1" type="radio" value="c">4</label>

                        <br><br>
                        <button type="submit" value="but1">Проверить</button>

                    </form>';

$q7 = '<form action="check_curse.php" method="post" style="border: 2px solid black; padding: 20px">
                        <span class="fs-4">Угловое ускорение</span>
                        <input name="test_id" value="7" style="display: none;">
                        <input name="quest_len" value="2" style="display: none;">
                        <br><br>

                        <p>Сколько будет 11 - 1 - 2?</p>
                        <label><input name="0" type="radio" value="a">10</label>
                        <label><input name="0" type="radio" value="b">9</label>
                        <label><input name="0" type="radio" value="c">8</label>

                        <br><br>

                        <p>Сколько будет 4 - 0?</p>
                        <label><input name="1" type="radio" value="a">3</label>
                        <label><input name="1" type="radio" value="b">2</label>
                        <label><input name="1" type="radio" value="c">4</label>

                        <br><br>
                        <button type="submit" value="but1">Проверить</button>

                    </form>';

$q8 = '<form action="check_curse.php" method="post" style="border: 2px solid black; padding: 20px">
                        <span class="fs-4">Контрольный тест : Движение по окружности</span>
                        <input name="test_id" value="8" style="display: none;">
                        <input name="quest_len" value="2" style="display: none;">
                        <br><br>

                        <p>Сколько будет 11 - 2?</p>
                        <label><input name="0" type="radio" value="a">10</label>
                        <label><input name="0" type="radio" value="b">9</label>
                        <label><input name="0" type="radio" value="c">1</label>

                        <br><br>

                        <p>Сколько будет 4 - 0?</p>
                        <label><input name="1" type="radio" value="a">4</label>
                        <label><input name="1" type="radio" value="b">2</label>
                        <label><input name="1" type="radio" value="c">23</label>

                        <br><br>
                        <button type="submit" value="but1">Проверить</button>

                    </form>';

$q9 = '<form action="check_curse.php" method="post" style="border: 2px solid black; padding: 20px">
                        <span class="fs-4">Виды движения</span>
                        <input name="test_id" value="9" style="display: none;">
                        <input name="quest_len" value="2" style="display: none;">
                        <br><br>

                        <p>Сколько будет 1 * 3 ?</p>
                        <label><input name="0" type="radio" value="a">3</label>
                        <label><input name="0" type="radio" value="b">9</label>
                        <label><input name="0" type="radio" value="c">1</label>

                        <br><br>

                        <p>Сколько будет 4?</p>
                        <label><input name="1" type="radio" value="a">4</label>
                        <label><input name="1" type="radio" value="b">2</label>
                        <label><input name="1" type="radio" value="c">0</label>

                        <br><br>
                        <button type="submit" value="but1">Проверить</button>

                    </form>';

