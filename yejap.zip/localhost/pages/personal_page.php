<?php
session_start();

if(!$_SESSION['id']){
    header('Location: ../index.php ');
}

//assets
require_once __DIR__ . '/../assets/blocks_html/blocks.php';
require_once __DIR__ . '/../assets/b_logic/courses_id.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="vieport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/styles/css.css">

    <title>Yejap education</title>
</head>

<!-- HEADER -->
<div class="container">
    <header class="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom">

        <!--LOGO-->
        <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-dark text-decoration-none">
            <svg class="bi me-2" width="40" height="32"><use xlink:href="#bootstrap"></use></svg>
            <span class="fs-3">Yejap</span>
        </a>

        <!--NAVIGATION-->
        <ul class="nav nav-pills">
            <li class="nav-item">
                <?php
                if($_SESSION['id']) {
                    echo '
                    <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#exampleModal3">
                        Выйти
                    </button>';
                }
                ?>
            </li>
        </ul>

    </header>
</div>

<body>

<section class="border p-4 container text-center mb-4 rounded-5">

    <span class="fs-1 slogan"><?php echo $_SESSION['full_name']; ?></span>
    <br><br><br>
    <span class="fs-3 slogan"><?php echo $_SESSION['email'];?></span>
    <br><br><br><br><br>
    <span class="fs-1 courses_head">Мои курсы:</span><br><br><br><br>

    <div class="courses">
        <?php
        if($_SESSION['id']){
            foreach ($_SESSION['courses'] as $key => $hey){
                echo $courses_dict[$hey];
            }
        }
        else{
            echo 'Зарегистрируйтесь, чтобы добавить курс в избранное';
        }
        ?>


    </div>



    <!-- Modal REGISTRATION -->
    <div class="modal fade" id="exampleModal1" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Регистрация</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="../assets/a_core/register.php" method="post">

                        <input name="email" type="email" class="form-control" aria-describedby="emailHelp" placeholder="email">
                        <input name="fname" type="text" class="form-control" placeholder="Имя">
                        <input name="lname" type="text" class="form-control" placeholder="Фамилия">
                        <input name="organization" type="text" class="form-control" placeholder="Организация">
                        <input name="password1" type="password" class="form-control" placeholder="Пароль">
                        <input name="password2" type="password" class="form-control" placeholder="Подтвердите пароль">

                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">Зарегистрироваться</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>


    <!-- Modal AUTHORIZATION -->
    <div class="modal modal_author fade" id="exampleModal2" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Вход</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="../assets/a_core/login.php" method="post">
                        <input name="email" type="email" class="form-control" aria-describedby="emailHelp" placeholder="email">
                        <input name="password" type="password" class="form-control" placeholder="Пароль">

                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">Войти</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>


    <!-- Modal EXIT -->
    <div class="modal modal_author fade" id="exampleModal3" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Вы действительно хотите выйти?</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="../assets/a_core/logout.php" method="post">
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" aria-label="Close"  data-bs-dismiss="modal">Нет</button>
                            <button type="submit" class="btn btn-primary">Да</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>


    <!-- Modal ADD EVENT -->
    <div class="modal modal_author fade" id="exampleModal4" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Добавить мероприятие</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="assets/sql/sql_add.php" class="add_event_modal" method="post">
                        <label for="exampleInputPassword1" class="add_event_modal_item">Название меропрития</label>
                        <input type="text" class="form-control add_event_modal_item" name="title" placeholder="Игра в мафию">

                        <label for="exampleInputPassword1" class="add_event_modal_item">Время проведения</label>
                        <input type="time" class="form-control add_event_modal_time add_event_modal_item" name="time">

                        <label for="exampleInputPassword1" class="add_event_modal_item" >День недели</label>
                        <select class="form-control add_event_modal_item" name="weekday">
                            <optgroup label="День недели">
                                <option value="1">Понедельник</option>
                                <option value="2">Вторник</option>
                                <option value="3">Среда</option>
                                <option value="4">Четверг</option>
                                <option value="5">Пятница</option>
                                <option value="6">Суббота</option>
                                <option value="7">Воскресенье</option>
                            </optgroup>
                        </select>

                        <label for="exampleInputPassword1">Введите описание</label>
                        <input type="text" class="form-control add_event_modal_description" name="text">


                        <div class="modal-footer" >
                            <button type="submit" class="btn btn-primary">Да</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>

</section>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js" integrity="sha384-IDwe1+LCz02ROU9k972gdyvl+AESN10+x7tBKgc9I5HFtuNz0wWnPclzo6p9vxnk" crossorigin="anonymous"></script>
</body>

<?php echo $footer1; ?>

</html>