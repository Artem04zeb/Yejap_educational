<?php
session_start();
require_once __DIR__ . '/../assets/a_core/connect.php';
require_once __DIR__ . '/../assets/blocks_html/blocks.php';
require_once __DIR__ . '/../assets/blocks_html/tests.php';

// Сразу, когда заходим на эту страницу, выставляем ID курса данной страницы
$_SESSION['course_id'] = 0;
$id_student = $_SESSION['id'];
$course_id = $_SESSION['course_id'];

// Берём статистику пользователя для данного курса
$result = mysqli_fetch_all(mysqli_query($connect, "SELECT * FROM `statistics` WHERE `id_student` = '$id_student' AND `id_course` = '$course_id'"), 1)[0]['points'];
$result_exploded = explode(';', $result);

// Приводим статистику к удобному виду
for($i = 0; $i < count($result_exploded); $i++){
    $result_exploded[$i] = explode('/', $result_exploded[$i]);
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="vieport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/styles/css.css">

    <title>Yejap education</title>
</head>

<!-- HEADER -->
<div class="container">
    <header class="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom">

        <!--LOGO-->
        <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-dark text-decoration-none">
            <svg class="bi me-2" width="40" height="32"><use xlink:href="#bootstrap"></use></svg>
            <span class="fs-3">Yejap</span>
        </a>

        <!--NAVIGATION-->
        <ul class="nav nav-pills">
            <li class="nav-item">
                <?php
                if($_SESSION['id']){
                    echo '
                    <a href="pages/personal_page.php">
                    <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="">
                        Личный кабинет
                    </button>
                    </a>';
                    echo '
                        <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#exampleModal3">
                            Выйти
                        </button>';
                }
                else{
                    echo '
                        <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#exampleModal1">
                            Зарегистрироваться
                        </button>
                        <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#exampleModal2">
                            Войти
                        </button>
                        ';
                }
                ?>
            </li>
            <!--
            <li class="nav-item"><a href="#" class="nav-link ">На всякий случай если нужна кнопка</a></li>
            !-->
        </ul>

    </header>
</div>

<body>

<section class="border p-4 container text-center mb-4 rounded-5">

    <div class="course_txt">
        <span class="fs-1" >О курсе:</span>
            Здесь должна быть инфа о курсе. Может быть предисловие от составителя. Напутсвие. Предупреждение. Для кого курс предназначен.
            В общем, вводная от составителя курса.
        <span class="fs-4" ></span>
        <form action="../assets/b_logic/add_course.php" method="post">
            <input name="course" value="1" style="display: none;">
            <input type="submit" value="Добавить курс в избранное">
        </form>
        <br><br><br>

        <span class="fs-2" >Механика</span>
        <p>
            <strong>Механика</strong> — это раздел физики, который изучает движение и взаимодействие тел. <br><br>
            Тела бывают разных размеров, могут иметь разные скорости, из-за этого механика состоит из нескольких разделов, основными из которых являются классическая, релятивистская и квантовая механика:
        </p>
        <ul>
            <li> <strong>Классическая механика Ньютона</strong> — это раздел механики, изучающий движение и взаимодействие макроскопических тел, обладающих малыми по сравнению со скоростью света в вакууме (300 000 км/с) скоростями.</li>
            <strong >Макроскопические тела</strong>  — это тела, состоящие из большого числа частиц (атомов или молекул).
            <li> <strong> Квантовая механика </strong>— это раздел механики, изучающий движение и взаимодействие микроскопических тел. </li>
            <strong>Микроскопические тела</strong>— это тела, состоящие из небольшого числа частиц (атомов или молекул).
            <li><strong>Релятивистская механика</strong> — это раздел механики, изучающий движение и взаимодействие тел, обладающих скоростями, близкими к скорости света в вакууме (300 000 км/с).</li>
        </ul>
        <p>
            Окружающие нас тела достаточно велики и движутся по сравнению со скоростью света достаточно медленно, поэтому их движение подчиняется законам Ньютона. Таким образом, область применения классической механики очень обширна. И в этой области человечество всегда будет пользоваться для описания движения тел законами Ньютона.
        </p>

        <span class="fs-3" >Кинематика</span>
        <details>
        <summary style="float: left;">
            Что такое кинематика?
            <?php
                if($_SESSION['id']){
                    echo '<progress value="' . $result_exploded[0][0] . '" max="' . $result_exploded[0][1] . '"></progress>';
                }
            ?>
        </summary><br>


            <div class="summary_inside">
            <span class="fs-4"><strong>Кинематика</strong></span> — это раздел механики, который занимается изучением механического движения тел, не смотря на причины его возникновения.
            <br>То есть вот у нас есть тело и оно может двигаться, то есть менять свое положение в пространстве относительно других тел с течением времени. Например, падение листьев, движение облаков, движение автомобиля. Это и изучает кинематика.
            <br><br><span class="fs-4" ><strong>Пространство и время</strong></span><br>
            Пространство и время — наиболее общие понятия физики и... наименее ясные. Все мы знаем, что такое пространство и что такое время, но дать четкого определения этим понятиям мы не можем.

            <br>Единственное что тут можно сказать это то, что время в Международной системе (СИ) время измеряют в <strong>секундах (с)</strong>.
            <br>Его также можно измерять в микросекундах (1 мкс = 0,000001 с), миллисекундах (1 мс = 0,001 с), минутах (1 мин = 60 с), часах (1 ч = 60 мин = 3600 с) и т.д.
            <br><br><span class="fs-4" ><strong>Относительно других тел</strong></span>
            <br>Согласно определению, движение — это “изменение положения тела … относительно других тел”, то есть оно относительно. Например, если в вагоне поезда лежит мяч, то относительно пассажира поезда мяч двигаться не будет, а относительно человека на перроне — будет.
            <br>Поэтому, чтобы можно было определить положение тела в пространстве в любое время, нужно выбрать <strong>систему отсчета</strong>, состоящую из тела отсчета (тело, относительно которого рассматривается движение), системы координат (точка отсчета совпадает с телом отсчета) и часов: рис 8 (Я).
            <br>Систем отсчета бесконечное количество, но среди них есть одна-две наиболее удобные, в которых движение выглядит проще.

            <?php echo $q0;?>

        </div>
        </details>
        <details open>
            <summary style="float: left;">Произвольное движение</summary><br>
            <div class="summary_inside">
                <details>
                    <summary style="float: left;">
                        Положение тела
                        <?php
                        if($_SESSION['id']){
                            echo '<progress value="' . $result_exploded[1][0] . '" max="' . $result_exploded[1][1] . '"></progress>';
                        }
                        ?>
                    </summary>
                    <div class="summary_inside">
                        <br><span class="fs-4" ><strong>Материальная точка</strong></span><br>
                        При попытке описать движение тела, возникает вопрос: как можно задать координату и скорость тела, если разные его части обладают разными координатами и скоростями?
                        <br>
                        Поэтому вводят <strong>материальную точку</strong>  — упрощенную модель тела, в которой мы пренебрегаем размерами тела, считая его за точку, обладающую всей массой тела.
                        <br>
                        Все о чем мы будем дальше говорить относится к материальной точке, т.е. тело = материальная точка.

                        <br><br><span class="fs-4" ><strong>Как определить положение тела?</strong></span><br>
                        Чтобы сказать о том, как движется тело, нужно знать его положение в пространстве. Оно характеризуется 4 величинами:
                        <br>
                        <ul>
                            <li>
                                <strong>Радиус-вектор</strong>— это вектор, соединяющий точку начала координат и точку в которой находится тело: r = x + y + z.
                                <br>Радиус-вектор показывает в каком направлении и на каком расстоянии от начала координат находится тело в данный момент времени
                                <br>Координаты радиус-вектора являются координатами тела.
                            </li>
                            <li>
                                <strong>Перемещение</strong>— вектор, соединяющий начальную точку нахождения тела в пространстве с конечной.
                                Вектор перемещения показывает из какой точки в какую точку передвинулось тело за время своего движения.

                                <br>Перемещение связано с радиус-вектором формулой: <strong style="color: red">FORMULA</strong>— радиус-вектор в конечной точке,— радиус-вектор в начальной точке.
                                <br>Перемещение на координатные оси.
                            </li>
                            <li>
                                <strong>Траектория</strong> — это линия по которой движется тело.
                            </li>
                            <li>
                                <strong>Путь</strong> — это длина участка траектории, пройденного телом за данный промежуток времени называется путем l.
                            </li>
                        </ul>
                        <br><span class="fs-4" ><strong>Единицы измерения расстояния.</strong></span><br>
                        В Международной системе (СИ) расстояние измеряют в метрах (м).
                        <br>
                        Расстояние также можно измерять в миллиметрах (1 мм = 0,001 м), сантиметрах (1 см = 0,01 м), дециметрах (1 дм = 0,1 м) и километрах (1 км = 1000 м) и т.д.
                    </div>

                    <?php echo $q1;?>

                </details><br>
                <details>
                    <summary style="float: left;">
                        Скорость
                        <?php
                        if($_SESSION['id']){
                            echo '<progress value="' . $result_exploded[2][0] . '" max="' . $result_exploded[2][1] . '"></progress>';
                        }
                        ?>
                    </summary>
                    <div class="summary_inside">
                        <br><span class="fs-4" ><strong>Что такое скорость?</strong></span><br>
                        Так, с положением тела в пространстве разобрались, но дело в том, что перемещение может происходить с разной быстротой. Поэтому вводят <strong>скорость</strong>  —  величину, характеризующая какое расстояние проходит тело в единицу времени.
                        <br><br>
                        Например, пешеход за 1 час проходит 5 км, значит его скорость равна 5 километров в час, а автомобиль за час проезжает 100 км, тогда его скорость равна 100 километров в час. Так скорость автомобиля больше скорости пешехода.
                        <br><br>Если вектор перемещения s разделить на интервал времени At, в течение которого это перемещение произошло, то мы получим <strong>среднюю скорость vср</strong> . Она так названа, из-за того, что также как и перемещение, описывает ситуацию в общем “тело совершило перемещение из точки A в точку B с такой скоростью”: стр 44 (М).
                        <br><br>Из-за того, что средняя скорость описывает движение в целом, то мы, зная ее скорость, не будем знать как двигалось тело в промежутке от A до B. Поэтому, если фиксировать перемещение за очень малые промежутки времени, потом делить это на это промежуток время, то мы будем получать скорость тела в каждый момент времени — <strong>мгновенную скорость v</strong> : стр 70. Она направлена по касательной траектории. Она показывает какое расстояние в единицу времени проходило тело если, начиная с этого момента оно начало двигаться с постоянной скоростью.
                        <br><br>Таким образом мгновенная скорость — первая производная перемещения по времени: стр 70 (М).
                        <br><br>Иногда полезно знать среднюю скорость тела, при прохождении траектории — <strong>путевую скорость</strong> : стр 72 (М).
                        <br>
                        <br><span class="fs-4" ><strong>Единицы измерения скорости</strong></span><br>
                        В Международной системе (СИ) скорость измеряют в метрах в секунду (м/с). Это значит, что за 1 секунду тело проходит путь, равный 1 метру.
                        <br><br>
                        Скорость тела можно измерять также в километрах в час (км/ч); километрах в секунду (км/с); сантиметрах в секунду (см/с)

                        <?php echo $q2;?>


                    </div>

                </details><br>
                <details>
                    <summary style="float: left;">
                        Ускорение
                        <?php
                        if($_SESSION['id']){
                            echo '<progress value="' . $result_exploded[3][0] . '" max="' . $result_exploded[3][1] . '"></progress>';
                        }
                        ?></summary>
                    <div class="summary_inside">
                        <br><span class="fs-4" ><strong>Что такое ускорение?</strong></span><br>
                        При движении тел их скорости обычно меняются либо по модулю, либо по направлению, либо же одновременно и по модулю, и по направлению. Поэтому вводят <strong>ускорение</strong>  — величину, характеризующую быстроту изменения вектора скорости. Чем больше ускорение, тем быстрее меняется скорость в единицу времени.
                        <br><br>Так, например, скорость шайбы, скользящей по льду, уменьшается с течением времени до полной ее остановки. Если взять в руки камень и разжать пальцы, то при падении камня его скорость быстро нарастает. Скорость любой точки окружности точила при неизменном числе оборотов в единицу времени меняется только по направлению, оставаясь постоянной по модулю: рис. 1.45(М). Если бросить камень под углом к горизонту, то его скорость будет меняться и по модулю, и по направлению.
                        <br><br>Таким образом, если векторы скорости и ускорения движущегося тела направлены в одну сторону, то модуль вектора скорости тела увеличивается, а если в противоположные — уменьшается.
                        <br><br>У многих из вас может возникнуть вопрос: не следует ли ввести величину, характеризующую быстроту изменения ускорения? Конечно, такую величину ввести можно, но в этом нет необходимости. Дело в том, что взаимодействие тел в мире определяет ускорение. Поэтому знать ускорение нам необходимо, а знание быстроты изменения ускорения ничего нового нам не даст.
                        <br><br>Подобно тому как вектор средней скорости играет преимущественно вспомогательную роль, среднее ускорение также не является основным понятием. Нужно уметь определять ускорение в каждой точке траектории. Это ускорение называется мгновенным. Именно мгновенное ускорение, как вы увидите впоследствии, определяется действием на данное тело окружающих тел.
                        <br><br>На разных участках траектории за одинаковые промежутки времени At изменение скорости Av может быть различным как по модулю, так и по направлению.
                        <ul>
                            <li>
                                <strong>Среднее ускорение aср</strong>  — это отношение изменения вектора скорости Av к интервалу времени At, в течение которого это изменение скорости произошло: стр 78 (М).
                                <br>Вектор среднего ускорения показывает в какую сторону и насколько изменяется вектор скорости в единицу времени.</li>
                            <br><li>
                                <strong>Мгновенное ускорение a</strong> — это предел отношения изменения вектора скорости Av к интервалу времени At, в течение которого это изменение скорости произошло, если интервал времени стремится к нулю: стр 79 (М).
                                <br>При произвольном движении вектор ускорения направлен внутрь траектории. При это его удобно разложить на составляющие по направлению скорости (тангенциальное) и перпендикулярно к ней (нормальное). </li>
                            <li style="margin-left: 20px">
                                <strong>Тангенциальное ускорение</strong> характеризует изменение скорости по модулю: стр 121, где dv — приращение модуля скорости за бесконечно малый интервал времени dt.
                            </li>
                            <li style="margin-left: 20px">
                                <strong>Нормальная ускорение</strong> характеризует изменение скорости по направлению: стр 120, где r — радиус кривизны кривой в данной точке.
                            </li>
                        </ul>
                        Полное ускорение равно сумме тангенциального и нормального ускорений: стр 120.
                        <br><br><span class="fs-4" ><strong>Единицы измерения ускорения</strong></span><br>
                        В Международной системе (СИ) ускорение измеряют в метрах в секунду в квадрате (м/с2). Это значит, что за 1 секунду модуль скорости тела меняется на 1 метр в секунду.
                        <br><br>
                        Ускорение можно измерять также в сантиметрах на секунду в квадрате (см/с2), километрах на час в квадрате (км/ч2).

                        <?php echo $q3;?>

                    </div>
                </details><br>
                <details>
                    <summary style="float: left;">
                        Контрольный тест
                        <?php
                        if($_SESSION['id']){
                            echo '<progress value="' . $result_exploded[4][0] . '" max="' . $result_exploded[4][1] . '"></progress>';
                        }
                        ?></summary>
                    <div class="summary_inside">
                        <br><br><br>
                        <?php echo $q4;?>
                </details><br>
            </div>
        </details>
        <details open>
            <summary style="float: left;">Движение по окружности</summary><br>

            <div class="summary_inside">
                Формулы для движения по окружности идентичны формулам для произвольного движения
                <details>
                    <summary style="float: left;">
                        Положение тела на окружности
                        <?php
                        if($_SESSION['id']){
                            echo '<progress value="' . $result_exploded[5][0] . '" max="' . $result_exploded[5][1] . '"></progress>';
                        }
                        ?>
                    </summary>
                    <div class="summary_inside">
                    <br><span class="fs-4" ><strong>Как определить положение тела?</strong></span><br>
                    При движении точки по окружности модуль радиус-вектора уже не меняется, но меняется его направление, поэтому самым удобным способом описать положение тела на окружности можно при помощи угла между произвольно выбранной осью и радиус-вектором: рис 1.86 (М).
                    <br><br>
                    Когда тело движется, то угол поворота радиус-вектора меняется и это можно описать формулой: ф = ф0 + Aф, где ф — угол в конечной точке, ф0 — угол в начальной точке, Aф— <strong>угловое перемещение</strong>  (величина, показывающая в какую сторону и на сколько изменился угол).
                    <br>
                    <br><span class="fs-4" ><strong>Единицы измерения угла</strong></span><br>
                    В Международной системе (СИ) угол измеряют в радианах (рад).
                    <br><br>
                    Проведем координатную ось Х через центр окружности (начало координат), вдоль которой движется точка (рис. 1.86). Тогда положение точки А на окружности в любой момент времени однозначно определяется углом ф между осью Х и радиусом-вектором А, проведенным из центра окружности к движущейся точке. Углы будем выражать в радианах.
                    <div>
                        <?php echo $q5;?>
                </details><br>
                <details>
                    <summary style="float: left;">
                        Угловая скорость
                        <?php
                        if($_SESSION['id']){
                            echo '<progress value="' . $result_exploded[6][0] . '" max="' . $result_exploded[6][1] . '"></progress>';
                        }
                        ?>
                    </summary>
                    <div class="summary_inside">
                        <br><span class="fs-4" ><strong>Что такое угловая скорость?</strong></span><br>
                        При движении точки угол φ изменяется. Аналогично обычной скорости введем <strong>угловую скорость</strong> , которая показывает какой угол и в каком направлении проходит дело в единицу времени.
                        <br><br>
                        Если при равномерном обращении за время At радиус-вектор повернулся на угол Аф, то быстрота обращения определится углом поворота в единицу времени. Быстроту обращения характеризуют угловой скоростью.
                        <br><br><span class="fs-4" ><strong>Единицы измерения угловой скорости</strong></span><br>
                        В Международной системе (СИ) угловая скорость измеряется в радианах в секунду (рад/с). Это значит, что за 1 секунду тело проходит угол, равный 1 радиану.
                        <br><br><span class="fs-4" ><strong>Основные виды угловой скорости</strong></span><br>
                        <ul>
                            <li>
                                <strong>Средняя угловая скорость ωср</strong> — это отношение угловое перемещение Aф к интервалу времени At, в течение которого это перемещение произошло: стр 123 (М).
                            </li>
                            <li>
                                <strong>Мгновенная угловая скорость ω</strong> — это предел отношения углового перемещения Aф к интервалу времени At, в течение которого это перемещение произошло, если интервал времени стремится к нулю: стр 123 (М).
                            </li>
                        </ul>
                        <br><span class="fs-4" ><strong>Связь между линейной и угловой скоростями</strong></span><br>
                        Скорость, с которой точка движется по окружности, часто называют линейной скоростью, чтобы подчеркнуть ее отличие от угловой скорости. Между линейной скоростью точки, обращающейся по окружности, и ее угловой скоростью существует связь.
                        <br><br>
                        Время, за которое тело прошло весь круг равно: t = 2pi/ω = 2piR/v. Отсюда 1/ω = R/v, то есть ω = v/R, значит v = ωR.
                        <?php echo $q6;?>
                    </div>
                </details><br>
                <details>
                    <summary style="float: left;">
                        Угловое ускорение
                        <?php
                        if($_SESSION['id']){
                            echo '<progress value="' . $result_exploded[7][0] . '" max="' . $result_exploded[7][1] . '"></progress>';
                        }
                        ?>
                    </summary>
                    <div class="summary_inside">
                        <br><span class="fs-4" ><strong>Что такое угловое ускорение?</strong></span><br>
                        Как и линейная скорость, угловая скорость тоже может меняться. В этом случае как и с линейным ускорением вводится <strong>угловое ускорение</strong> : стр 125.
                        <br><br>
                        Угловое ускорение равно производной угловой скорости по времени.
                        <br><strong>Связь угловой скорости и углового ускорения: стр 125.</strong>
                        <br><br><span class="fs-4" ><strong>Что такое угловое ускорение?</strong></span><br>
                        <ul>
                            <li>
                                <strong>Среднее угловое ускорение bср</strong> — это отношение изменения углового ускорения Aω к интервалу времени At, в течение которого это изменение скорости произошло: стр 125 (М).
                            </li>
                            <li>
                                <strong>Мгновенное угловое ускорение b</strong> — это предел отношения изменения углового ускорения Aω к интервалу времени At, в течение которого это изменение произошло, если интервал времени стремится к нулю: стр 125 (М).
                            </li>
                        </ul>
                        <br><span class="fs-4" ><strong>Связь линейного ускорения с угловым</strong></span><br>
                        С изменением угловой скорости точки меняется и ее линейная скорость. Нормальное ускорение связано согласно формуле (1.28.10) с угловой скоростью и не зависит, следовательно, от углового ускорения. Но тангенциальное ускорение, определяемое формулой (1.27.4), выражается через угловое ускорение: стр 126.
                        <?php echo $q7;?>
                    </div>
                </details><br>
                <details>
                    <summary style="float: left;">
                        Контрольный тест
                        <?php
                        if($_SESSION['id']){
                            echo '<progress value="' . $result_exploded[8][0] . '" max="' . $result_exploded[8][1] . '"></progress>';
                        }
                        ?>
                    </summary>
                    <div class="summary_inside">
                        <br><br><br>
                        <?php echo $q8;?>
                </details><br>
            </div>
        </details>
        <details >
            <summary style="float: left;">
                Виды движения
                <?php
                if($_SESSION['id']){
                    echo '<progress value="' . $result_exploded[9][0] . '" max="' . $result_exploded[9][1] . '"></progress>';
                }
                ?>
            </summary>
            <div class="summary_inside">
                <br><span class="fs-4" ><strong>Классификация движения</strong></span><br>
                По значениям, которые принимают нормальное и тангенциальное ускорения, можно классифицировать различные движения точки.
                <ul>
                    <li> По скорости
                        <li style="margin-left: 20px">
                        Если at = 0, то точка движется равномерно.
                        </li>
                        <li style="margin-left: 20px">
                            Если at ≠ 0, то точка движется неравномерно
                        </li>
                        <li style="margin-left: 20px">
                            Если at = const, то точка движется равноускоренно
                        </li>
                    </li>
                    <li>
                        По траектории
                        <li style="margin-left: 20px">
                            Если an = 0, то точка движется по прямой.
                        </li>
                        <li style="margin-left: 20px">
                            Если an ≠ 0, то точка движется по кривой
                        </li>
                        <li style="margin-left: 20px">
                            Если an = const, то точка движется по окружности.
                        </li>
                    </li>
                </ul>
                <?php echo $q9;?>
            </div>

        </details>
    </div>

    <!-- Modal REGISTRATION -->
    <div class="modal fade" id="exampleModal1" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Регистрация</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="../assets/a_core/register.php" method="post">

                        <input name="email" type="email" class="form-control" aria-describedby="emailHelp" placeholder="email">
                        <input name="fname" type="text" class="form-control" placeholder="Имя">
                        <input name="lname" type="text" class="form-control" placeholder="Фамилия">
                        <input name="organization" type="text" class="form-control" placeholder="Организация">
                        <input name="password1" type="password" class="form-control" placeholder="Пароль">
                        <input name="password2" type="password" class="form-control" placeholder="Подтвердите пароль">

                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">Зарегистрироваться</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>


    <!-- Modal AUTHORIZATION -->
    <div class="modal modal_author fade" id="exampleModal2" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Вход</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="../assets/a_core/login.php" method="post">
                        <input name="email" type="email" class="form-control" aria-describedby="emailHelp" placeholder="email">
                        <input name="password" type="password" class="form-control" placeholder="Пароль">

                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">Войти</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>


    <!-- Modal EXIT -->
    <div class="modal modal_author fade" id="exampleModal3" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Вы действительно хотите выйти?</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="../assets/a_core/logout.php" method="post">
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" aria-label="Close"  data-bs-dismiss="modal">Нет</button>
                            <button type="submit" class="btn btn-primary">Да</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>


    <!-- Modal ADD EVENT -->
    <div class="modal modal_author fade" id="exampleModal4" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Добавить мероприятие</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="assets/sql/sql_add.php" class="add_event_modal" method="post">
                        <label for="exampleInputPassword1" class="add_event_modal_item">Название меропрития</label>
                        <input type="text" class="form-control add_event_modal_item" name="title" placeholder="Игра в мафию">

                        <label for="exampleInputPassword1" class="add_event_modal_item">Время проведения</label>
                        <input type="time" class="form-control add_event_modal_time add_event_modal_item" name="time">

                        <label for="exampleInputPassword1" class="add_event_modal_item" >День недели</label>
                        <select class="form-control add_event_modal_item" name="weekday">
                            <optgroup label="День недели">
                                <option value="1">Понедельник</option>
                                <option value="2">Вторник</option>
                                <option value="3">Среда</option>
                                <option value="4">Четверг</option>
                                <option value="5">Пятница</option>
                                <option value="6">Суббота</option>
                                <option value="7">Воскресенье</option>
                            </optgroup>
                        </select>

                        <label for="exampleInputPassword1">Введите описание</label>
                        <input type="text" class="form-control add_event_modal_description" name="text">


                        <div class="modal-footer" >
                            <button type="submit" class="btn btn-primary">Да</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>

</section>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js" integrity="sha384-IDwe1+LCz02ROU9k972gdyvl+AESN10+x7tBKgc9I5HFtuNz0wWnPclzo6p9vxnk" crossorigin="anonymous"></script>
</body>

<?php echo $footer1; ?>

</html>